import re
inp=input("Quadratic Equation: ")
if inp.startswith('x2'):
    inp = '1' + inp
list=re.split(r'x2|x',inp)
if list[0] == '' or list[0] == '+':
    list[0] = '1'
elif list[0] == '-':
    list[0] = '-1'

if list[1] == '' or list[1] == '+':
    list[1] = '1'
elif list[1] == '-':
    list[1] = '-1'

if list[2] == '' or list[2] == '+':
    list[2] = '1'
elif list[2] == '-':
    list[2] = '-1'


a=int(list[0])
b=int(list[1])
c=int(list[2])
det=b**2 - 4*a*c
if det<0:
    print("Roots are complex")
else:
    r1=(-1*b + (det)**(0.5))/(2*a)
    r2=(-1*b - (det)**(0.5))/(2*a)
    print(f'{r1} {r2} are the roots')
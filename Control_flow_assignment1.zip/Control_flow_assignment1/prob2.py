menu="1. Soup and Salad\n2. Pasta with meat sauce\n3. Chef's Special\nWhich number would you like to order?"
inp=input("1. Soup and Salad\n2. Pasta with meat sauce\n3. Chef's Special\nWhich number would you like to order?")
list=menu.split("\n")
list.remove(list[len(list)-1])
if(int(inp)>len(list)):
    print("Sorry, that is not a valid choice.")
else:
    print(f'One {list[int(inp)-1][3:]} coming right up!')
def addition(*args):
    total=sum(args)
    print(total)

    
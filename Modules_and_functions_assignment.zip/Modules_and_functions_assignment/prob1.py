import math
x=int(input("x: "))
y=int(input("y: "))
print(f'{math.pow(x,y)}, {math.sqrt(x)}')
def getEvenNumbers(lst):
    return list(filter(lambda x: x%2==0,lst))
def func1(x,y):
    list=[]
    for i in range(x,y+1):
        if i%2==0:
            list.append(i)
    return list

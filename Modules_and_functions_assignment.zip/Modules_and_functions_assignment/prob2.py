import itertools
input_string = 'ABCDE'
permutations = list(itertools.permutations(input_string, 3))
print(permutations)
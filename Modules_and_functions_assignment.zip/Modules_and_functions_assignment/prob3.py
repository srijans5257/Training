def unique_list(list):
    new_list=[]
    new_set=set()
    for i in range(len(list)):
        new_set.add(list[i])
    for i in new_set:
        new_list.append(i)
    return new_list
inp=input("Enter String: ")
list=inp.split(" ")
new_list=unique_list(list)
print(new_list)
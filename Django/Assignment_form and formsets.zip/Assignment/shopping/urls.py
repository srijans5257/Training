from django.urls import path
from .views import item_list
from . import views
urlpatterns=[
    path('', views.home, name='home'),
    path('items/', item_list, name='items'),
    path('form/',views.form,name='form'),
    path('login/',views.login_view,name='login'),
    path('signup/',views.signup_view,name='signup')
]

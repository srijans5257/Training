from django.contrib import admin

# Register your models here.
from .models import shopping_item 
    
admin.site.register(shopping_item)
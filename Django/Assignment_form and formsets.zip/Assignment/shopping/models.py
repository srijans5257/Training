from django.db import models
from django.core.validators import MinValueValidator
# Create your models here.
class shopping_item(models.Model):
    name=models.CharField(max_length=100)
    price=models.FloatField(validators=[MinValueValidator(0.0)])
    Discount=models.IntegerField(validators=[MinValueValidator(0)])

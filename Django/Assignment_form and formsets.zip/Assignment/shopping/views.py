from django.shortcuts import render
from django.http import HttpResponse
from .models import shopping_item
from django.contrib.auth.models import User
from .forms import shopping_item_form,login_form,UserForm, ProfileForm, UserFormSet, ProfileFormSet

from django.shortcuts import redirect
from django.contrib.auth import authenticate,login as auth_login
# Create your views here.
def home(request):
  return HttpResponse("Hello ")
def item_list(request):
  items=shopping_item.objects.all()
  return render(request,'item_list.html',{'items':items})
def form(request):
  if request.method == 'POST':
        form = shopping_item_form(request.POST)
        if form.is_valid():
            form.save()
            return redirect('item_list')
  else:
        form = shopping_item_form()
  return render(request,'form.html',{'form': form})
def login_view(request):
  if request.method == 'POST':
            username=request.POST.get('username')
            email=request.POST.get('email')
            password=request.POST.get('password')
            user=authenticate(request,username=username,email=email,password=password)
            if user is not None:
                auth_login(request,user)
                return redirect('home')
            else:
                return render(request,'login.html',{'error': 'Invalid entry'})
  return render(request,'login.html')
def signup_view(request):
    if request.method=='POST':
        user_formset=UserFormSet(request.POST,prefix='user')
        profile_formset=ProfileFormSet(request.POST,prefix='profile')
        if user_formset.is_valid() and profile_formset.is_valid():
            user_data=user_formset.cleaned_data[0]
            profile_data=profile_formset.cleaned_data[0]

            user=User.objects.create_user(
                username=profile_data['name'],
                email=user_data['email'],
                password=user_data['password']
            )
            return redirect('login')
    else:
        user_formset=UserFormSet(prefix='user')
        profile_formset=ProfileFormSet(prefix='profile')
    return render(request,'signup.html',{
        'user_formset': user_formset,
        'profile_formset': profile_formset
    })

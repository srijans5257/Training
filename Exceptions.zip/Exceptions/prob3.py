class CustomException(Exception):
    def __init__(self, message):
        self.message = message

try:
    raise CustomException("Error occured.")
except CustomException as e:
    print(f"Caught an exception: {e.message}")

inp=input("Enter a number: ")
try:
    a=3+inp
except TypeError:
    print(3+int(inp))
else:
    print(a)#if try completes without exception, i.e., input is already coverted to int
finally:
    print("Successful")
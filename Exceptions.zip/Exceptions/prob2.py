def divide_by_zero(inp):
    return int(inp)/0
inp=input("Enter a number: ")
try:
    divide_by_zero(inp)
except ZeroDivisionError:
    print("Can't divide by zero")
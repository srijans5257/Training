def divide_by_zero(inp):
    try:
        a=inp/0
    except ZeroDivisionError:
        print("Can not divide by zero")
divide_by_zero(5)

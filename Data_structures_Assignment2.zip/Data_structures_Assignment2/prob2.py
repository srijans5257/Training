vowels=['a','e','i','o','u','A','E','I','O','U']
inp=input("Use only words and spaces in this text input: ")
list=inp.split(" ")
output=[]
for i in range(len(list)):
    if(list[i][0] in vowels):
        new=list[i]+"hay"
        output.append(new)
    else:
        new=list[i][1:]+list[i][0]+"ay"
        output.append(new)
for i in range(len(output)):
    print(output[i])

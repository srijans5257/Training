def are_colliding(tup1,tup2):
    dist=((tup1[0]-tup2[0])**2 + (tup1[1]-tup2[1])**2)**(0.5)
    if dist>tup1[2]+tup2[2]:
        return False
    else:
        return True
print(are_colliding((0,0,1),(3,3,1)))
print(are_colliding((5,5,2),(2,8,3)))
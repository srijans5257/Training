list_classes=[]
list_grades=[]
i=int(input("How many classes did you take: "))
for j in range(i):
    x=input("Name of the class: ")
    list_classes.append(x)
    y=int(input("Grade in that class: "))
    list_grades.append(y)
print("Report Card:" )
sum=0
for j in range(i):
    sum+=list_grades[j]
Average=sum/i
j=0
for j in range(i):
    print(f'{list_classes[j]}-{list_grades[j]}')
print(f'Overall Gpa - {Average}')

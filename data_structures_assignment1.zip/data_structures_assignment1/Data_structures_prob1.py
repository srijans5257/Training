def sorting(list):
    x=0
    new_list=[]
    length=len(list)
    for x in range(length):
        maxi=0
        i=0
        for j in range(len(list)):
            if list[j]>maxi:
                maxi=list[j]
                i=j
        del list[i]
        new_list.append(maxi)
    return new_list
list=[]
i=0
for i in range(0,10):
    num=int(input("Enter a number from the list to be sorted: "))
    list.append(num)
list=sorting(list)
i=0
for i in range(len(list)):
    print(list[i])

    
    

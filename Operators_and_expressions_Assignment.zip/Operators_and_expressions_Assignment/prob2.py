inp=int(input("Enter a number: "))
print(inp**2)
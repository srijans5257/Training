inp=int(input("Enter a number: "))
def odd_even(inp):
    if(inp%2==0):
        print("It is an even number.")
    else:
        print("It is an odd number.")
odd_even(inp)
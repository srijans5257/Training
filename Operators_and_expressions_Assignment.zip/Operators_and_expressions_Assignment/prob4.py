def squares():
    list=[]
    for i in range(20):
        list.append((i+1)**2)
    for i in range(5):
        print(list[len(list)-i-1])
squares()
import statistics
inp=input("Enter numbers with one space: ")
list=inp.split(" ")
list.sort()
median=0
if(len(list)%2==0):
    median=(int(list[len(list)//2 - 1])+int(list[len(list)//2]))/2
else:
    median=int(list[len(list)//2])
sum=0
for i in range(len(list)):
    sum+=int(list[i])
Mean=sum/len(list)
list_num=[]
for i in range(len(list)):
    list_num.append(int(list[i]))
mode=max(list_num,key=list_num.count)
print(f'Mean={Mean}, Median={median}, Mode={mode}')
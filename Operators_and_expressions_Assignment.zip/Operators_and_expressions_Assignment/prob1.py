inp=input("Enter expression with spaces: ")
list=inp.split(" ")
inp1=int(list[0])
inp2=int(list[2])
if(list[1]=='+'):
    print(inp1+inp2)
elif(list[1]=='-'):
    print(inp1-inp2)
elif(list[1]=='*'):
    print(inp1*inp2)
if(list[1]=='/'):
    print(inp1/inp2)
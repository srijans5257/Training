inp=input("Enter line by line and finish with ok: ")
output=0
while inp!='ok':
    list=inp.split(" ")
    if list[0]=='D':
        output+=int(list[1])
    else:
        output-=int(list[1])
    inp=input("Enter line by line and finish with ok: ")
print(output)
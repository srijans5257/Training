inp=input("Enter tuple: ")
list=[]
while(inp!='ok'):
    list.append(inp)
    inp=input("Enter tuple: ")
list.sort()
print(list)

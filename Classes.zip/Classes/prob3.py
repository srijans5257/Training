class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

class Quadrilateral:
    def __init__(self,p1,p2,p3,p4):
        self.p1=p1
        self.p2=p2
        self.p3=p3
        self.p4=p4

class Trapezoid(Quadrilateral):
    def __init__(self,p1,p2,p3,p4,height):
        super().__init__(p1,p2,p3,p4)
        self.height=height
    def area(self,p1,p2,p3,p4,height):
        p1p2=pow(pow(p1.x-p2.x,2)+pow(p1.y-p2.y,2),0.5)
        p3p4=pow(pow(p3.x-p4.x,2)+pow(p3.y-p4.y,2),0.5)
        return 0.5*(p1p2+p3p4)*height
class Parallelogram(Quadrilateral):
    def __init__(self,p1,p2,p3,p4,base,height):
        super().__init__(p1,p2,p3,p4)
        self.height=height
        self.base=base
    def area(self,base,height):
        return base*height
class Rectangle(Parallelogram):
    def __init__(self,p1,p2,p3,p4,width,height):
        super().__init__(p1,p2,p3,p4,width,height)
        self.height=height
        self.width=width
    def area(self,width,height):
        return width*height
class Square(Rectangle):
    def __init__(self,p1,p2,p3,p4,side):
        super().__init__(p1,p2,p3,p4,side,side)
        self.side=side
    def area(self,side):
        return side**2
def main():

    p1 = Point(0, 0)
    p2 = Point(4, 0)
    p3 = Point(3, 2)
    p4 = Point(1, 2)
    p5 = Point(0, 0)
    p6 = Point(4, 0)
    p7 = Point(4, 3)
    p8 = Point(0, 3)

    trapezoid = Trapezoid(p1, p2, p3, p4, 2)
    parallelogram = Parallelogram(p1, p2, p7, p8, 4, 3)
    rectangle = Rectangle(p1, p2, p7, p8, 4, 3)
    square = Square(p1, Point(2, 0), Point(2, 2), Point(0, 2), 2)

    print(f"Trapezoid area: {trapezoid.area(p1, p2, p3, p4, 2)}")

    print(f"Parallelogram area: {parallelogram.area(4,3)}")

    print(f"Rectangle area: {rectangle.area(4,3)}")

    print(f"Square area: {square.area(2)}")

if __name__ == "__main__":
    main()

import random

class Player:
    pass

class GuessGame:
    def startGame(self):
        p1=Player()
        p2=Player()
        p3=Player()
        num=random.randint(0,10)
        inp1=int(input("Enter a Number-p1(0-10): "))
        inp2=int(input("Enter a Number-p2(0-10): "))
        inp3=int(input("Enter a Number-p3(0-10): "))
        while inp1!=num and inp2!=num and inp3!=num:
            print("No matches! Enter again.")
            inp1=int(input("Enter a Number-p1(0-10): "))
            inp2=int(input("Enter a Number-p2(0-10): "))
            inp3=int(input("Enter a Number-p3(0-10): "))
        if inp1==num:
            print("P1 wins")    
        if inp2==num:
            print("P2 wins")    
        if inp3==num:
            print("P3 wins")    


class GameLauncher:
    def main():
        game=GuessGame()
        game.startGame()
if __name__ == "__main__":
    GameLauncher.main()
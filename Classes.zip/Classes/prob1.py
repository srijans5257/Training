class Student:
     def __init__(self,m1,m2):
          self.m1=m1
          self.m2=m2
     def __add__(self,other):#operator overloading
          m1=self.m1+other.m1
          m2=self.m2+other.m2
          s3=Student(m1,m2)
          return s3
     def __str__(self):#method overriding
          m1=self.m1
          m2=self.m2
          return f'{m1} {m2}'
def mul(a1=1,a2=1,a3=1):#method overloading
     return a1*a2*a3    

s1=Student(58,69)
s2=Student(60,64)
s3=s1+s2 #operator overloading
print(s3.m1,s3.m2)
# print(s3) would not work as it returns the address of s3. We can change this by method overriding
print(s3)
a1=8
a2=0.5
# a3=9
print(mul(a1,a2))#method overloading. Works for multiplication of 2 as well as 3 numbers

    
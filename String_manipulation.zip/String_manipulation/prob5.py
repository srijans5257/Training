inp1=input()
inp2=input()
len1=len(inp1)
len2=len(inp2)
mid=len1//2
new_string=inp1[:mid]+inp2+inp1[mid:]
print(f'{new_string}')
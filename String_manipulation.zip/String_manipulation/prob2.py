inp=input("Enter a String: ")
output=""
for i in range(len(inp)):
    if inp[i]!='a' and inp[i]!='e' and inp[i]!='i' and inp[i]!='o' and inp[i]!='u' and inp[i]!='A' and inp[i]!='E' and inp[i]!='I' and inp[i]!='O' and inp[i]!='U' and inp[i]!=' ' and inp[i]!=',':
        pass
    else:
        output+=inp[i]
print(f'{output}')
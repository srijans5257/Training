num=1
print("Number: {}".format(num))
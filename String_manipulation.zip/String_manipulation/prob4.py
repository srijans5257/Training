inp=input("Enter String: ")
char=inp[0]
new_string=inp[0]
for i in range(1,len(inp)):
    if inp[i].lower()==char.lower():
        new_string+='$'
    else:
        new_string+=inp[i]
print(f'{new_string}')
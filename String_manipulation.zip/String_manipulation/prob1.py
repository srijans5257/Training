inp=input("Enter your full name: ")
new_string=""
list=inp.split(" ")
for i in range(len(list)-1):
    new_string+=list[i][0] + '.'
new_string+=list[len(list)-1]
print(f'{new_string}')
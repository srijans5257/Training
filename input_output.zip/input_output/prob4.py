import string
def generate():
    for i in string.ascii_uppercase:
        filename=f'{i}.txt'
        with open(filename,'w') as file:
            file.write(f'This is file {filename}.')
        print(f'Created {filename}')
generate()
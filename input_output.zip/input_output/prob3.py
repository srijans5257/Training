def combine(file1,file2):
    with open(file1,'r') as f1, open(file2,'r') as f2:
        lines1=f1.readlines()
        lines2=f2.readlines()
        if len(lines1)!=len(lines2):
            print("Different number of lines.")
        for i,j in zip(lines1,lines2):
            combined=i.strip() + " " + j.strip()
            print(combined) 
combine('file.txt','file2.txt')
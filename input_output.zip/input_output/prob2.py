def count_words(filename):
    with open(filename,'r') as f:
        text=f.read()
    text=text.replace(',', ' ')
    list=text.split(" ")
    return len(list)
filename="file.txt"
print(count_words(filename))
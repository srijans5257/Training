inp=input("Provide unit of temperature that you are giving(C or F): ")
inp2=input("Temoerature: ")
if inp=="C":
    F=int(inp2)*(9/5) +32
    print(F)
else:
    C=(int(inp2)-32)*(5/9)
    print(C)

